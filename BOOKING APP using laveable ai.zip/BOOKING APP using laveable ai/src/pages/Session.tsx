import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Zap, Battery, Activity, Clock, IndianRupee, ArrowLeft } from "lucide-react";

interface Booking {
  id: string;
  slot_id: string;
  start_time: string;
  duration: number;
  kwh_requested: number;
  status: string;
  energy_delivered: number;
  cost: number;
}

interface Port {
  voltage: number;
  current: number;
  soc: number;
  energy: number;
  charging: boolean;
}

export default function Session() {
  const { bookingId } = useParams<{ bookingId: string }>();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [port, setPort] = useState<Port | null>(null);
  const [loading, setLoading] = useState(true);
  const [elapsedTime, setElapsedTime] = useState(0);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchBookingData();

    // Update elapsed time every second
    const timer = setInterval(() => {
      if (booking) {
        const start = new Date(booking.start_time).getTime();
        const now = Date.now();
        setElapsedTime(Math.floor((now - start) / 1000));
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [bookingId, booking?.start_time]);

  useEffect(() => {
    if (!booking) return;

    // Set up realtime subscription for port updates
    const channel = supabase
      .channel(`port-${booking.slot_id}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "ports",
          filter: `id=eq.${booking.slot_id}`,
        },
        (payload) => {
          setPort(payload.new as Port);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [booking?.slot_id]);

  const fetchBookingData = async () => {
    try {
      const { data: bookingData, error: bookingError } = await supabase
        .from("bookings")
        .select("*")
        .eq("id", bookingId)
        .single();

      if (bookingError) throw bookingError;

      setBooking(bookingData);

      const { data: portData, error: portError } = await supabase
        .from("ports")
        .select("voltage, current, soc, energy, charging")
        .eq("id", bookingData.slot_id)
        .single();

      if (portError) throw portError;

      setPort(portData);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load session data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStopCharging = async () => {
    if (!booking) return;

    try {
      const energyDelivered = port?.energy || 0;
      const cost = energyDelivered * 10; // ₹10 per kWh

      // Update booking
      await supabase
        .from("bookings")
        .update({
          status: "completed",
          energy_delivered: energyDelivered,
          cost: cost,
          completed_at: new Date().toISOString(),
        })
        .eq("id", bookingId);

      // Update port
      await supabase
        .from("ports")
        .update({
          booked: false,
          charging: false,
          booking_id: null,
          energy: 0,
        })
        .eq("id", booking.slot_id);

      toast({
        title: "Session Ended",
        description: `Total cost: ₹${cost.toFixed(2)}`,
      });

      navigate("/history");
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to stop charging",
        variant: "destructive",
      });
    }
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!booking || !port) {
    return (
      <div className="text-center">
        <p className="text-muted-foreground">Session not found</p>
        <Button onClick={() => navigate("/dashboard")} className="mt-4">
          Back to Dashboard
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <Button
        variant="ghost"
        onClick={() => navigate("/dashboard")}
        className="mb-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Button>

      <Card className="border-border/50 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-6 w-6 text-primary" />
              Charging Session
            </CardTitle>
            {port.charging ? (
              <Badge className="bg-success">Active</Badge>
            ) : (
              <Badge variant="outline">Waiting</Badge>
            )}
          </div>
          <CardDescription>
            Slot: {booking.slot_id.toUpperCase()}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-1">
                  <Battery className="h-4 w-4" />
                  SOC
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-primary">{port.soc.toFixed(1)}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-1">
                  <Activity className="h-4 w-4" />
                  Voltage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">{port.voltage.toFixed(1)} V</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-1">
                  <Zap className="h-4 w-4" />
                  Current
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">{port.current.toFixed(1)} A</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{formatTime(elapsedTime)}</p>
              </CardContent>
            </Card>
          </div>

          <div className="rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 p-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <p className="text-sm text-muted-foreground">Energy Delivered</p>
                <p className="text-3xl font-bold text-primary">{port.energy.toFixed(2)} kWh</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Current Cost</p>
                <p className="flex items-center text-3xl font-bold">
                  <IndianRupee className="h-6 w-6" />
                  {(port.energy * 10).toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground">@ ₹10 per kWh</p>
              </div>
            </div>

            <div className="mt-4 grid gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Requested:</span>
                <span className="font-medium">{booking.kwh_requested} kWh</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-medium">{booking.duration} minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">CO₂ Saved:</span>
                <span className="font-medium text-success">
                  {(port.energy * 0.9).toFixed(2)} kg
                </span>
              </div>
            </div>
          </div>

          <Button
            onClick={handleStopCharging}
            variant="destructive"
            className="w-full"
            disabled={!port.charging && port.energy === 0}
          >
            Stop Charging
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
