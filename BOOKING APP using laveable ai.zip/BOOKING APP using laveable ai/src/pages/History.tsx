import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Zap, Calendar, IndianRupee, Leaf } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Booking {
  id: string;
  slot_id: string;
  start_time: string;
  duration: number;
  kwh_requested: number;
  status: string;
  energy_delivered: number;
  cost: number;
  completed_at: string | null;
}

export default function History() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("Not authenticated");
      }

      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      setBookings(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load booking history",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-success">Completed</Badge>;
      case "active":
        return <Badge className="bg-primary">Active</Badge>;
      case "booked":
        return <Badge className="bg-warning">Booked</Badge>;
      case "expired":
        return <Badge variant="outline">Expired</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat("en-IN", {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "Asia/Kolkata",
    }).format(date);
  };

  const totalEnergy = bookings.reduce((sum, b) => sum + (b.energy_delivered || 0), 0);
  const totalCost = bookings.reduce((sum, b) => sum + (b.cost || 0), 0);
  const totalCO2Saved = totalEnergy * 0.9;

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Charging History</h1>
        <p className="mt-2 text-muted-foreground">
          View your past charging sessions
        </p>
      </div>

      {bookings.length > 0 && (
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Energy</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-primary">{totalEnergy.toFixed(2)} kWh</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Spent</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="flex items-center text-2xl font-bold">
                <IndianRupee className="h-5 w-5" />
                {totalCost.toFixed(2)}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-1">
                <Leaf className="h-4 w-4 text-success" />
                CO₂ Saved
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-success">{totalCO2Saved.toFixed(2)} kg</p>
            </CardContent>
          </Card>
        </div>
      )}

      {bookings.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Zap className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg font-medium text-muted-foreground">No bookings yet</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Start charging to see your history here
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => (
            <Card key={booking.id} className="border-border/50 transition-all hover:shadow-md">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Zap className="h-5 w-5 text-primary" />
                    {booking.slot_id.toUpperCase()}
                  </CardTitle>
                  {getStatusBadge(booking.status)}
                </div>
                <CardDescription className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {formatDate(booking.start_time)}
                </CardDescription>
              </CardHeader>

              <CardContent>
                <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-semibold">{booking.duration} min</p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground">Requested</p>
                    <p className="font-semibold">{booking.kwh_requested} kWh</p>
                  </div>

                  {booking.status === "completed" && (
                    <>
                      <div>
                        <p className="text-sm text-muted-foreground">Delivered</p>
                        <p className="font-semibold text-primary">
                          {booking.energy_delivered.toFixed(2)} kWh
                        </p>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground">Cost</p>
                        <p className="flex items-center font-semibold">
                          <IndianRupee className="h-4 w-4" />
                          {booking.cost.toFixed(2)}
                        </p>
                      </div>
                    </>
                  )}
                </div>

                {booking.status === "completed" && booking.energy_delivered > 0 && (
                  <div className="mt-3 rounded-md bg-success/10 p-2 text-sm">
                    <p className="flex items-center gap-1 text-success">
                      <Leaf className="h-4 w-4" />
                      CO₂ saved: {(booking.energy_delivered * 0.9).toFixed(2)} kg
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
