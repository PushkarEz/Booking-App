import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { Battery, Zap, Activity, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Port {
  id: string;
  booked: boolean;
  charging: boolean;
  voltage: number;
  current: number;
  soc: number;
  energy: number;
  car_present: boolean;
  booking_id: string | null;
  updated_at: string;
}

export default function Dashboard() {
  const [ports, setPorts] = useState<Port[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchPorts();

    // Set up realtime subscription
    const channel = supabase
      .channel("ports-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "ports",
        },
        (payload) => {
          console.log("Port updated:", payload);
          fetchPorts();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchPorts = async () => {
    const { data, error } = await supabase
      .from("ports")
      .select("*")
      .order("id");

    if (error) {
      toast({
        title: "Error",
        description: "Failed to fetch charging slots",
        variant: "destructive",
      });
    } else {
      setPorts(data || []);
    }
    setLoading(false);
  };

  const getStatusBadge = (port: Port) => {
    if (port.charging) {
      return <Badge className="bg-success">Charging</Badge>;
    }
    if (port.booked) {
      return <Badge className="bg-warning">Booked</Badge>;
    }
    return <Badge variant="outline" className="border-primary text-primary">Available</Badge>;
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="mt-2 text-muted-foreground">
          Real-time charging slot availability
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {ports.map((port) => (
          <Card
            key={port.id}
            className="relative overflow-hidden border-border/50 transition-all hover:shadow-lg"
          >
            <div className="absolute right-0 top-0 h-32 w-32 -translate-y-8 translate-x-8 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 blur-3xl" />
            
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  {port.id.toUpperCase()}
                </CardTitle>
                {getStatusBadge(port)}
              </div>
              <CardDescription>
                {port.charging
                  ? "Actively charging"
                  : port.booked
                  ? "Reserved"
                  : "Ready to use"}
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Activity className="h-3 w-3" />
                    Voltage
                  </div>
                  <p className="text-lg font-semibold">{port.voltage.toFixed(1)} V</p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Zap className="h-3 w-3" />
                    Current
                  </div>
                  <p className="text-lg font-semibold">{port.current.toFixed(1)} A</p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Battery className="h-3 w-3" />
                    SOC
                  </div>
                  <p className="text-lg font-semibold">{port.soc.toFixed(1)}%</p>
                </div>

                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">Energy</div>
                  <p className="text-lg font-semibold">{port.energy.toFixed(2)} kWh</p>
                </div>
              </div>

              <Button
                className="w-full"
                disabled={port.booked || port.charging}
                onClick={() => navigate(`/book/${port.id}`)}
              >
                {port.booked || port.charging ? "Not Available" : "Book Now"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
