import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Zap, ArrowLeft } from "lucide-react";

export default function BookSlot() {
  const { slotId } = useParams<{ slotId: string }>();
  const [duration, setDuration] = useState("");
  const [kwhRequested, setKwhRequested] = useState("");
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
      }
    };
    getUser();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userId) {
      toast({
        title: "Error",
        description: "Please log in to book a slot",
        variant: "destructive",
      });
      return;
    }

    if (!duration || !kwhRequested) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const durationNum = parseInt(duration);
    const kwhNum = parseFloat(kwhRequested);

    if (durationNum <= 0 || kwhNum <= 0) {
      toast({
        title: "Error",
        description: "Duration and kWh must be positive numbers",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Check if slot is still available
      const { data: portData, error: portError } = await supabase
        .from("ports")
        .select("booked")
        .eq("id", slotId)
        .single();

      if (portError) throw portError;

      if (portData.booked) {
        toast({
          title: "Slot Unavailable",
          description: "This slot has already been booked",
          variant: "destructive",
        });
        setLoading(false);
        navigate("/dashboard");
        return;
      }

      // Create booking
      const { data: bookingData, error: bookingError } = await supabase
        .from("bookings")
        .insert({
          user_id: userId,
          slot_id: slotId,
          duration: durationNum,
          kwh_requested: kwhNum,
          status: "booked",
        })
        .select()
        .single();

      if (bookingError) throw bookingError;

      // Update port as booked
      const { error: updateError } = await supabase
        .from("ports")
        .update({
          booked: true,
          booking_id: bookingData.id,
        })
        .eq("id", slotId);

      if (updateError) throw updateError;

      toast({
        title: "Success!",
        description: "Slot booked successfully",
      });

      navigate(`/session/${bookingData.id}`);
    } catch (error: any) {
      console.error("Booking error:", error);
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to book slot",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Button
        variant="ghost"
        onClick={() => navigate("/dashboard")}
        className="mb-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Button>

      <Card className="border-border/50 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            Book Charging Slot
          </CardTitle>
          <CardDescription>
            Slot: <span className="font-semibold text-foreground">{slotId?.toUpperCase()}</span>
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                placeholder="e.g., 60"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                min="1"
                required
              />
              <p className="text-sm text-muted-foreground">
                How long do you need to charge?
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="kwh">Estimated kWh Required</Label>
              <Input
                id="kwh"
                type="number"
                step="0.1"
                placeholder="e.g., 10.5"
                value={kwhRequested}
                onChange={(e) => setKwhRequested(e.target.value)}
                min="0.1"
                required
              />
              <p className="text-sm text-muted-foreground">
                Estimated energy needed (₹10 per kWh)
              </p>
            </div>

            {kwhRequested && (
              <div className="rounded-lg bg-secondary p-4">
                <p className="text-sm font-medium text-foreground">Estimated Cost</p>
                <p className="text-2xl font-bold text-primary">
                  ₹{(parseFloat(kwhRequested) * 10).toFixed(2)}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Actual cost based on energy delivered
                </p>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Booking...
                </>
              ) : (
                "Confirm Booking"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
