-- Create profiles table for user information
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create charging ports table (compatible with ESP32)
CREATE TABLE public.ports (
  id TEXT PRIMARY KEY, -- port0, port1, port2
  booked BOOLEAN DEFAULT FALSE,
  charging BOOLEAN DEFAULT FALSE,
  voltage FLOAT DEFAULT 0,
  current FLOAT DEFAULT 0,
  soc FLOAT DEFAULT 0, -- State of charge percentage
  energy FLOAT DEFAULT 0, -- Energy delivered in kWh
  car_present BOOLEAN DEFAULT FALSE,
  booking_id UUID,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create bookings table
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  slot_id TEXT NOT NULL REFERENCES public.ports(id),
  start_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  duration INTEGER NOT NULL, -- in minutes
  kwh_requested FLOAT,
  status TEXT DEFAULT 'booked', -- booked, active, completed, expired
  energy_delivered FLOAT DEFAULT 0,
  cost FLOAT DEFAULT 0, -- ₹10 per kWh
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Insert initial charging ports
INSERT INTO public.ports (id) VALUES 
  ('port0'),
  ('port1'),
  ('port2');

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- RLS Policies for ports (anyone can view, system updates)
CREATE POLICY "Anyone can view ports"
  ON public.ports FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can update ports"
  ON public.ports FOR UPDATE
  TO authenticated
  USING (true);

-- RLS Policies for bookings
CREATE POLICY "Users can view own bookings"
  ON public.bookings FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create bookings"
  ON public.bookings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bookings"
  ON public.bookings FOR UPDATE
  USING (auth.uid() = user_id);

-- Create function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'full_name',
    NEW.email
  );
  RETURN NEW;
END;
$$;

-- Trigger to create profile on user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Enable realtime for ports table
ALTER PUBLICATION supabase_realtime ADD TABLE public.ports;

-- Create function to update port timestamp
CREATE OR REPLACE FUNCTION public.update_port_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Trigger to update timestamp on port changes
CREATE TRIGGER update_ports_timestamp
  BEFORE UPDATE ON public.ports
  FOR EACH ROW
  EXECUTE FUNCTION public.update_port_timestamp();